package compiladores2018sala;

/**
 *
 * @author Bianca
 */
public class Token 
{
    protected EnumToken name;
    protected EnumToken attribute;
    
    public Token(EnumToken n, EnumToken a)
    {
        this.name = n;
        attribute = a;
    }
    
    public Token(EnumToken n)
    {
        name = n;
    }
}
