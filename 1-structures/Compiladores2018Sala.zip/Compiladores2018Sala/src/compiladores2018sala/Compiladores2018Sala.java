/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package compiladores2018sala;

/**
 *
 * @author Bianca
 */
public class Compiladores2018Sala 
{
    public static void main(String[] args) 
    {
        java.util.Scanner leitor = new java.util.Scanner(System.in);
        System.out.println("Fonte:");
        
        TabelaSimples table = new TabelaSimples();
        Scanner tokenizer = new Scanner(leitor.nextLine(), table);
        
        table.insertKeyWords();
        
        Token t;// = tokenizer.nextToken();
                
        do//while (t != null)
        {
            t =tokenizer.nextToken();
            System.out.printf("%s(%s) ", t.name, t.attribute);            
        }while (t.name != EnumToken.EOF);
    }

}
