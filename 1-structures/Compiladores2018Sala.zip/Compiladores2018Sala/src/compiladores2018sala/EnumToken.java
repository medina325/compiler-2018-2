/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compiladores2018sala;

/**
 *
 * @author Bianca
 */
public enum EnumToken 
{
    UNDEF,
    IF,
    THEN,
    ELSE,
    ID,
    RELOP,
    NUMBER,
    LT,
    LE,
    GT,
    GE,
    EQ,
    NE,
    INT_LIT,
    FLOAT_LIT,
    DOUBLE_LIT,
    EOF
}
