package compiladores2018sala;

/**
 *
 * @author Bianca
 */
public class TabelaSimples 
{
    protected String[] keywords;
    
    public TabelaSimples()
    {
        keywords = new String[3];      
    }
    
    public void insertKeyWords()
    {
        keywords[0] = new String("if");
        keywords[1] = new String("then");
        keywords[2] = new String("else");
    }
    
    public int exists(String str)
    {
        for (int i = 0; i < keywords.length; i++)
            if (str.equals(keywords[i]))
                return i;
        
        return -1;
    }
}
