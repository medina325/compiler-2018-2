package compiladores2018sala;

/**
 *
 * @author Bianca
 */
public class Scanner 
{
    private String input;
    private TabelaSimples table;
    private int pos;
    
    public Scanner(String input, TabelaSimples t)
    {
        this.input = input;
        table = t;
        pos = 0;
    }
    
    //Método para retornar o próximo token. Espaços em branco são ignorados.
    public Token nextToken()
    {
        String lexeme = "";
        Token tok = null;
        
        int state = 0;        
                
        //System.out.println(pos);
        
        if (pos == input.length())
            return tok = new Token(EnumToken.EOF);
        
        //Consome espaços em branco
        while (pos < input.length() && Character.isWhitespace(input.charAt(pos)))
            pos++;
        
        //Trecho para reconhecer um RELOP
        if (input.charAt(pos) == '>' || input.charAt(pos) == '<' || 
            input.charAt(pos) == '=')
        {
            //É um RELOP
            tok = new Token(EnumToken.RELOP);
            //int state = 0;
            
            while (true)
            {
                switch (state)
                {
                    case 0:
                        if (input.charAt(pos) == '<')
                        {
                            pos++;
                            state = 1;
                        }
                        else if (input.charAt(pos) == '=')
                        {
                            pos++;
                            state = 5;
                        }
                        else if (input.charAt(pos) == '>')
                        {
                            pos++;
                            state = 6;
                        }
                        else
                            fail();                   

                        break;
                    case 1:
                        if (pos < input.length()) 
                        {
                            if (input.charAt(pos) == '=')
                            {
                                pos++;
                                state = 2;
                            }
                            else if (input.charAt(pos) == '>')
                            {
                                pos++;
                                state = 3;
                            }
                            else
                            {
                                pos++;
                                state = 4;
                            }
                        }
                        else
                        {
                            pos++;
                            state = 4;
                        }
                        break;
                    case 2:
                        //tok = new Token(Enum.RELOP);                    
                        tok.attribute = EnumToken.LE;

                        return tok;
                    case 3:
                        //tok = new Token(Enum.RELOP);                    
                        tok.attribute = EnumToken.NE;

                        return tok;
                    case 4:
                        pos--;
                        //tok = new Token(Enum.RELOP);                    
                        tok.attribute = EnumToken.LT;

                        return tok;
                    case 5:
                        //tok = new Token(Enum.RELOP);                    
                        tok.attribute = EnumToken.EQ;

                        return tok;
                    case 6:
                        if (pos < input.length() && input.charAt(pos) == '=')
                        {
                            pos++;
                            state = 7;
                        }
                        else
                        {
                            pos++;
                            state = 8;
                        }
                        break;
                    case 7:
                        //tok = new Token(Enum.RELOP);                    
                        tok.attribute = EnumToken.GE;

                        return tok;
                    case 8:
                        pos--;
                        //tok = new Token(Enum.RELOP);                    
                        tok.attribute = EnumToken.GT;

                        return tok;
                }//switch
            }//while
        }
        else if (Character.isLetter(input.charAt(pos)))
        {
            //Identificador
            state = 9;
            while (true)
            {
                switch(state)
                {
                    case 9:
                        if (Character.isLetter(input.charAt(pos)))
                        {
                            lexeme += input.charAt(pos);
                            pos++;
                            state = 10;                        
                        }
                        else
                            fail();

                        break;
                    case 10:
                        while (pos < input.length() && Character.isLetterOrDigit(input.charAt(pos)))
                        {
                            lexeme += input.charAt(pos);
                            pos++;
                        }
                        
                        pos++;
                        state = 11;
                        
                        /*if (Character.isLetterOrDigit(input.charAt(pos)))
                        {
                            pos++;
                            state = 10;
                        }
                        else
                        {
                            pos++;
                            state = 11;
                        }*/
                        
                        

                        break;
                    case 11:
                        pos--;
                        
                        int index = table.exists(lexeme);
                        
                        if (index == 0)
                            tok = new Token(EnumToken.IF);
                        else if (index == 1)
                            tok = new Token(EnumToken.THEN);
                        else if (index == 2)
                            tok = new Token(EnumToken.ELSE);
                        else
                            tok = new Token(EnumToken.ID);
                        //tok.attribute
                        
                        return tok;                   
                }
            }
        }
        return tok;
    }//Fim nextToken
    
    public void fail()
    {
        System.out.println("Erro léxico");
    }
}
