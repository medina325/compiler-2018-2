/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package mjcompiler;

/**
 *
 * @author Bianca
 */
public class MJCompiler 
{
    //Método main para testar apenas o analisador léxico. Considera que a
    //entrada está salva em um arquivo com nome "teste1.mj"
    public static void main(String[] args) 
    {       
        Scanner scanner = new Scanner("teste1.mj");
        
        Token tok;
        
        do
        {
            tok = scanner.nextToken();
            System.out.print(tok.name + " ");
        } while (tok.name != EnumToken.EOF);
     
    }

}
