package mjcompiler;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.StringCharacterIterator;

/**
 *
 * @author Bianca
 */
public class Scanner 
{
    private static String input;
    private StringCharacterIterator inputIt;
    private int lineNumber;

    //Construtor da classe que recebe como argumento o nome do arquivo texto
    //com o código do programa a ser analisado. O arquivo é aberto e seu 
    //conteúdo é copiado para o buffer de entrada (input)
    public Scanner(String inputFileName)
    {
        File inputFile = new File(inputFileName);       
        
        try
        {
            //Tenta abrir o arquivo para leitura
            FileReader fr = new FileReader(inputFile);
            
            //Instancia um vetor de caracteres para armazenar o arquivo
            int size = (int)inputFile.length();            
            char[] buffer = new char[size];
        
            //Preenche o vetor com os caracteres lidos
            fr.read(buffer, 0, size);
            
            //Instancia um objeto de String com vetor de caracteres preenchido 
            input = new String(buffer);
            
            //Instancia e inicializa o iterador de caracteres para percorrer a
            //string input a partir de seu início
            inputIt = new StringCharacterIterator(input);
            
            //Inicializa a contagem de linhas em 1
            lineNumber = 1;
        }
        catch(FileNotFoundException e)
        {
            System.err.println("Arquivo não encontrado");
        }
        catch(IOException e)
        {
            System.err.println("Erro na leitura do arquivo");
        }
    }
    
    //Método para reconhecer e retornar o próximo token
    public Token nextToken()
    {
        //Instancia um novo objeto token, inicialmente indefinido
        Token tok = new Token(EnumToken.UNDEF);        
        
        //Preencher com o código para reconhecimento dos tokens da linguagem
        
        return tok;
    }//nextToken
}
