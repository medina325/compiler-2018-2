package mjcompiler;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.StringCharacterIterator;

/**
 *
 * @author Bianca
 */
public class Scanner 
{
    private static String input;
    private StringCharacterIterator inputIt;
    private SymbolTable st;
    private int lineNumber;
    
    public Scanner(SymbolTable globalST, String inputFileName)
    {
        File inputFile = new File(inputFileName);       
        st = globalST;
        
        try
        {
            FileReader fr = new FileReader(inputFile);
            
            int size = (int)inputFile.length();            
            char[] buffer = new char[size];
        
            fr.read(buffer, 0, size);
            
            input = new String(buffer);
            
            inputIt = new StringCharacterIterator(input);
            
            lineNumber = 1;
        }
        catch(FileNotFoundException e)
        {
            System.err.println("Arquivo não encontrado");
        }
        catch(IOException e)
        {
            System.err.println("Erro na leitura do arquivo");
        }
    }
    
    public Token nextToken()
    {
        //Instancia um novo objeto token, inicialmente indefinido
        Token tok = new Token(EnumToken.UNDEF); 
        String lexeme = "";
        
        //Preencher com o código para reconhecimento dos tokens da linguagem
        
        if(/* alguma condição*/)
        {
            
        }
        else if ()//Trecho de reconhecimento de identificadores e palavras reservadas (mesmo padrão)
        {
            //Consome os caracteres...
            
            //Ao final do reconhecimento, busca o lexema reconhecido na tabela 
            //de símbolos para ver se está lá.
            STEntry entry = st.get(lexeme);
                
            if (entry != null)
                tok.name = entry.tokName;
            else
                tok.name = EnumToken.ID;                       

            tok.value = lexeme;
            tok.lineNumber = lineNumber;

            return tok;
        }
        //Continua....
        else
        {
            throw new CompilerException("Token desconhecido");
        }
        
        return tok;
        
        
    }//nextToken
}
