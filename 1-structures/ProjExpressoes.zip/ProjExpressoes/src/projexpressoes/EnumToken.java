package projexpressoes;

/**
 *
 * @author bianca
 */
public enum EnumToken 
{
    UNDEF,
    ID,
    MATOP,
    ADDOP,
    SUBOP,
    MULOP,
    DIVOP,
    NUMBER,
    INTEGER,
    FLOAT,
    DOUBLE,
    LPAREN,
    RPAREN,
    EOF
}
