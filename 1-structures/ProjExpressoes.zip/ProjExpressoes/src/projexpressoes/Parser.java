package projexpressoes;

/**
 *
 * @author bianca
 */
public class Parser 
{
    private Scanner scanner;
    private Token lToken;
    
    public Parser(String str)
    {
        scanner = new Scanner(str);
        
        lToken = scanner.nextToken();
    }

    public void run()
    {
        goal();
        match(EnumToken.EOF);
        System.out.println("Compilação terminada");
    }
    
    private void advance()
    {
        lToken = scanner.nextToken();
    }
    
    private void match(EnumToken tName)
    {
        if (tName != lToken.name)
        {
            System.out.printf("Símbolo %s não esperado\n", lToken.lexeme);
            System.exit(1);
        }
        else
            advance();
    }
    
    private void goal()
    {
        expr();
    }
    
    private void expr()
    {
        term();
        exprLine();
    }
    
    private void exprLine()
    {
        if (lToken.attribute == EnumToken.ADDOP)
        {
            advance();
            term();
            exprLine();
        }
        else if (lToken.attribute == EnumToken.SUBOP)
        {
            advance();
            term();
            exprLine();
        }
        else
            ;//Palavra vazia, não faz nada
    }
    
    private void term()
    {
        factor();
        termLine();
    }
    
    private void termLine()
    {
        if (lToken.attribute == EnumToken.MULOP)
        {
            advance();
            factor();
            termLine();
        }
        else if (lToken.attribute == EnumToken.DIVOP)
        {
            advance();
            factor();
            termLine();
        }
        else
            ;
    }
    
    private void factor()
    {
        if (lToken.name == EnumToken.ID)
            advance();
        else if (lToken.name == EnumToken.NUMBER)
            advance();
        else if (lToken.name == EnumToken.LPAREN)
        {
            advance();
            expr();
            match(EnumToken.RPAREN);
        }
        else
            fail("Erro sintático: Fator esperado\n");
    }
    
    public void fail(String str)
    {
        System.out.println(str);
        
        System.exit(1);
    }
}
