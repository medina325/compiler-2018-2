package projexpressoes;

/**
 *
 * @author bianca
 */
public class ProjExpressoes 
{
    public static void main(String[] args) 
    {
        java.util.Scanner leitor = new java.util.Scanner(System.in);
        System.out.println("Expressão:");
        
        Parser parser = new Parser(leitor.nextLine());        
        
        parser.run();
        
    }

}
