package projexpressoes;

/**
 *
 * @author bianca
 */
public class Token 
{
    protected EnumToken name;
    protected EnumToken attribute;
    protected String lexeme;
    
    public Token(EnumToken n, EnumToken a)
    {
        this.name = n;
        attribute = a;
    }
    
    public Token(EnumToken n)
    {
        name = n;
    }
    
    public Token()
    {}
}
