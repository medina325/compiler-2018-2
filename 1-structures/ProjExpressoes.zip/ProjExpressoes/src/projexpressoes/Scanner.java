package projexpressoes;

import java.text.StringCharacterIterator;

/**
 *
 * @author bianca
 */
public class Scanner 
{
    private String input;
    private StringCharacterIterator inputIt;
    
    public Scanner(String input)
    {
        this.input = input;
        inputIt = new StringCharacterIterator(this.input);
    }
    
    //Método para retornar o próximo token. Espaços em branco são ignorados.
    public Token nextToken()
    {
        String lexeme = "";
        char ch = inputIt.current();
        Token tok = new Token(EnumToken.UNDEF);
                        
        //System.out.println(pos);
        
        //Fim de arquivo
        if (inputIt.getIndex() >= inputIt.getEndIndex() || ch == StringCharacterIterator.DONE)
        {
            tok.name = EnumToken.EOF;
         
            return tok;
        }
        
        //Consome espaços em branco
        while (Character.isWhitespace(inputIt.current()))      
        {
            //if (inputIt.current() == '\n')
              //  lineNumber++;
            inputIt.next();
        }
        
        //Trecho para reconhecer um MATOP
        if (inputIt.current() == '+' || inputIt.current() == '-' || 
            inputIt.current() == '*' || inputIt.current() == '/')
        {
            //É um operador
            tok.name = EnumToken.MATOP;
            //int state = 0;
            
            switch (inputIt.current())
            {
                case '+':
                    tok.attribute = EnumToken.ADDOP;         
                    break;
                case '-':
                    tok.attribute = EnumToken.SUBOP;
                    break;
                case '*':
                    tok.attribute = EnumToken.MULOP;
                    break;
                case '/':
                    tok.attribute = EnumToken.DIVOP;
                    break;
            }
            
            lexeme += inputIt.current();
            inputIt.next();
        }
        else if (Character.isLetter(inputIt.current()))
        {            
            //É um ID
            tok.name = EnumToken.ID;
            
            do
            {
                lexeme += inputIt.current();
                inputIt.next();                
            }while (Character.isLetterOrDigit(inputIt.current()));          
            
        }
        else if (Character.isDigit(inputIt.current()))
        {            
            //É um número
            tok.name = EnumToken.NUMBER;
            
            do
            {
                lexeme += inputIt.current();
                inputIt.next();                
            }while (Character.isDigit(inputIt.current()));          
            
            tok.attribute = EnumToken.INTEGER;
            
            if (inputIt.current() == '.')
            {
                lexeme += inputIt.current();
                inputIt.next();
                
                if (!Character.isDigit(inputIt.current()))
                    fail("Número mal formado!\n");
                
                do
                {
                    lexeme += inputIt.current();
                    inputIt.next();                
                }while (Character.isDigit(inputIt.current()));          
                
                tok.attribute = EnumToken.FLOAT;
            }    
            if (inputIt.current() == 'E')
            {
                lexeme += inputIt.current();
                inputIt.next();

                if ((inputIt.current() == '+') || (inputIt.current() == '-'))
                {
                    lexeme += inputIt.current();
                    inputIt.next();
                }

                if (!Character.isDigit(inputIt.current()))
                    fail("Número mal formado!\n");

                do
                {
                    lexeme += inputIt.current();
                    inputIt.next();                
                }while (Character.isDigit(inputIt.current()));

                tok.attribute = EnumToken.DOUBLE;
            }                
        }
        else if (inputIt.current() == '(')
        {
            tok.name = EnumToken.LPAREN;
            lexeme += inputIt.current();
            
            inputIt.next();
        }
        else if (inputIt.current() == ')')
        {
            tok.name = EnumToken.RPAREN;
            lexeme += inputIt.next();
            
            inputIt.next();
        }
        
        tok.lexeme = lexeme;
        
        return tok;
    }//Fim nextToken
    
    public void fail(String str)
    {
        System.out.println(str);
        
        System.exit(1);
    }
}
