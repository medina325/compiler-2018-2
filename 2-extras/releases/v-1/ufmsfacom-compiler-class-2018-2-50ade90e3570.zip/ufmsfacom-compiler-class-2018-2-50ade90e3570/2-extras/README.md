# Disciplina de Redes de Computadores.

## Extras
**Nessa pasta contém os materias extras passados em sala, bem como: slides, documentos, exemplos, apostilas e projetos de exemplo de terceiros, que foram usuandos durante o período da disciplina de Redes de Computadores, ufms 2018-2.**