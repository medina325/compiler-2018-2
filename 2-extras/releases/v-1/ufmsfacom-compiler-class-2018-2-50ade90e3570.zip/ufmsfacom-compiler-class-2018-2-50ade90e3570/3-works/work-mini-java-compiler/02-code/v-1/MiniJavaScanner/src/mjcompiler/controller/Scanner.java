package mjcompiler.controller;

import mjcompiler.model.Token;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.StringCharacterIterator;
import mjcompiler.helpers.util.EnumToken;
import mjcompiler.model.STEntry;
import mjcompiler.model.SymbolTable;

public class Scanner 
{
    private static String input;
    private StringCharacterIterator inputIt;
    private int lineNumber;
    private SymbolTable st;
    
   
    //Construtor da classe que recebe como argumento o nome do arquivo texto
    //com o código do programa a ser analisado. O arquivo é aberto e seu 
    //conteúdo é copiado para o buffer de entrada (input)
    public Scanner(SymbolTable globalST, String inputFileName)
    {
        st = globalST;
        
        try
        {
            // Correção do problema de EOF
            // inputFileName += '\n';
            if (inputFileName.isEmpty()){
                inputFileName += '\n';
            }
            if (!inputFileName.substring(inputFileName.length() - 1).equals(" ")){
                inputFileName += '\n';
            }
            //Instancia um objeto de String com vetor de caracteres preenchido 
            input = inputFileName; // Instancia um objeto de String com vetor de caracteres preenchido
            //System.out.printf("%d %s\n", size, input);
            inputIt = new StringCharacterIterator(input); // Instancia e inicializa o iterador de caracteres
                                                          // para percorrer a string input a partir de seu início
         
            lineNumber = 1; // Inicializa contagem de linhas com 1
        }
        catch(Exception e)
        {
            System.err.println("Erro na leitura do arquivo");
        }
    }
    
    //Método para reconhecer e retornar o próximo token
    public Token nextToken()
    {
        Token tok = new Token(EnumToken.UNDEF); // Instancia objeto de Token inicialmente indefinido         
        String lexeme = "";
        
        // Ignoro espaços em branco, comentários e caracteres \n, \t, \r e \f             
        while(Character.isWhitespace(inputIt.current()) || inputIt.current() == '/' || inputIt.current() == '\\')
        {
            if(inputIt.current() == '\\') // se for '\'
            {
                inputIt.next();
                if(inputIt.current() == 'n' || inputIt.current() == 't' || inputIt.current() == 'r' ||
                   inputIt.current() == 'f')
                {
                    inputIt.next();
                }
            }
            else if(inputIt.current() == '/') //Ignorando comentários
            {
                inputIt.next();
                // Comentário do tipo //
                if(inputIt.current() == '/') // Significa que achou //
                {
                    inputIt.next();
                    while(inputIt.current() != '\n') // Ignora até pular linha
                        inputIt.next();
                    inputIt.next(); // Próximo símbolo
                }
                // Comentário do tipo /* */
                else if(inputIt.current() == '*') // Significa que achou um /*
                {
                    boolean t = true;
                    inputIt.next();
                    while(t){ // Enquanto não aparecer "*/"
                        if(inputIt.current() == '*'){
                            inputIt.next();
                            if(inputIt.current() == '/'){ // encerra comentário
                                t = false;
                            }
                        }
                        else
                        {
                            inputIt.next(); // Dentro do comentário só ignoro
                        }   
                    }
                    inputIt.next(); // Pŕoximo símbolo
                }
                else // Div
                {
                    tok.name = EnumToken.RELOP;
                    tok.attribute = EnumToken.DIV;
                    inputIt.next(); // Próximo símbolo
                    return tok;
                }
            }
            if(inputIt.current() == '\n') // Se caracter for \n entao incrementa número de linhas
                lineNumber++;
            
            inputIt.next();
        }
        // Se acabou, retorno token EOF
        if(inputIt.getIndex() >= inputIt.getEndIndex() - 1 || inputIt.current() == StringCharacterIterator.DONE)
        {
            tok.name = EnumToken.EOF;
            return tok;
        }   
        // Reconhecer ID (que começa sempre com letra)
        else if(Character.isLetter(inputIt.current())) // Se caracter atual é uma letra maiúscula ou minúscula
        {
            lexeme += inputIt.current();
            
            inputIt.next();
            // Enquanto forem letras, dígitos ou underscores
            while(Character.isLetterOrDigit(inputIt.current()) || inputIt.current() == '_')
            {
                lexeme += inputIt.current();
                inputIt.next();
            }
            
            //Ao final do reconhecimento, busca o lexema reconhecido na tabela 
            //de símbolos para ver se está lá.
            STEntry entry = st.get(lexeme);
                
            if (entry != null)
                tok.name = entry.tokName;
            else
                tok.name = EnumToken.ID;                       

            tok.value = lexeme;
            tok.lineNumber = lineNumber;
            System.out.printf("%s\n", lexeme);
            
        }
        // Reconhecendo números
        else if(Character.isDigit(inputIt.current())) // Reconhecer números
        {
            tok.attribute = EnumToken.NUMBER; // É um número
            inputIt.next();
            // Enquanto forem dígitos
            while(Character.isDigit(inputIt.current())){
                //lexeme += inputIt.current();
                inputIt.next();
            }
                
            tok.name = EnumToken.INTEGER_LITERAL; // Todos números em MiniJava são inteiros
        }
        //Reconhecendo operadores (exceto DIV)
        else if(inputIt.current() == '&' || inputIt.current() == '<' || inputIt.current() == '>' ||
                inputIt.current() == '+' || inputIt.current() == '-' || inputIt.current() == '*' ||
                inputIt.current() == '=' || inputIt.current() == '!')
        {
            tok.attribute = EnumToken.RELOP;
            
            switch(inputIt.current())
            {
                case '&': // And
                    inputIt.next();
                    if(inputIt.current() == '&')
                    {
                        tok.name = EnumToken.AND;
                    }    
                    inputIt.next();
                    break;
                
                case '<': // Lesser than
                    tok.name = EnumToken.LT;
                    inputIt.next();
                    break;
                
                case '>': // Greater than
                    tok.name = EnumToken.GT;
                    inputIt.next();
                    break;
                
                case '+': // Plus
                    tok.name = EnumToken.PLUS;
                    inputIt.next();
                    break;
                
                case '-': // Minus
                    tok.name = EnumToken.MINUS;
                    inputIt.next();
                    break;
                
                case '*': // Mult
                    tok.name = EnumToken.MULT;
                    inputIt.next();
                    break;
                
                case '=': 
                    inputIt.next();
                    if(inputIt.current() == '=') // Equals
                    {
                        tok.name = EnumToken.EQ;
                        inputIt.next();
                    }
                    else // se próximo símbolo não for '=' então é operação de atribuição
                    {
                        tok.name = EnumToken.ATTRIB;
                        inputIt.next();
                    }
                    break;
                
                case '!':
                    inputIt.next();
                    if(inputIt.current() == '=') // Not equals
                    {
                        tok.name = EnumToken.NE;
                        inputIt.next();
                    }
                    else
                    {
                        tok.name = EnumToken.NOT;
                        inputIt.next();
                    } 
            }
            //lexeme += inputIt.current();
        }
        // Reconhecendo separadores
        else if(inputIt.current() == '(' || inputIt.current() == ')' || 
                inputIt.current() == '[' || inputIt.current() == ']' ||
                inputIt.current() == '{' || inputIt.current() == '}' ||
                inputIt.current() == ';' || inputIt.current() == '.' ||
                inputIt.current() == ',')
        {
            tok.attribute = EnumToken.SEP;
            //tok.name = EnumToken.
            switch(inputIt.current())
            {
                case '(':
                    tok.name = EnumToken.LPARENTHESE;
                    inputIt.next();
                    break;
                case ')':
                    tok.name = EnumToken.RPARENTHESE;
                    inputIt.next();
                    break;
                case '[':
                    tok.name = EnumToken.LBRACKET;
                    inputIt.next();
                    break;
                case ']':
                    tok.name = EnumToken.RBRACKET;
                    inputIt.next();
                    break;
                case '{':
                    tok.name = EnumToken.LBRACE;
                    inputIt.next();
                    break;
                case '}':
                    tok.name = EnumToken.RBRACE;
                    inputIt.next();
                    break;
                case ';':
                    tok.name = EnumToken.SEMICOLON;
                    inputIt.next();
                    break;
                case '.':
                    tok.name = EnumToken.PERIOD;
                    inputIt.next();
                    break;
                case ',':
                    tok.name = EnumToken.COMMA;
                    inputIt.next();
                    break;
                    
                    
                    
            } // fim switch
        }
        /*else{
            throw new CompilerException("toin");
        }*/
        return tok;
    } // fim nextToken
    public String getInput()
    {
        return this.input;
    }
}