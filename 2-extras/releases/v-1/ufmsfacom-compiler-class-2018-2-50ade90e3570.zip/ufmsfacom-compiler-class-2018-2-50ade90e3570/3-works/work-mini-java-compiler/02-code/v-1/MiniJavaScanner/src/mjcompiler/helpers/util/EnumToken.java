package mjcompiler.helpers.util;

public enum EnumToken 
{
    UNDEF,
    SEP, // separadores
    CLASS, // class
    PUBLIC, // public
    STATIC, // static
    VOID, // void
    MAIN, // main
    ID, 
    IF, // if
    WHILE, // while
    SOPRINTLN, // system.out.println
    THIS, // this
    STRING, // String
    INT, // int
    BOOLEAN, // boolean
    NEW, // new
    EXTENDS, // extends
    LBRACKET, // [ 
    RBRACKET, // ]
    LPARENTHESE, // (
    RPARENTHESE, // )
    LBRACE, // {
    RBRACE, // }
    PERIOD, // .
    COMMA, // ,
    SEMICOLON, // ;
    ELSE, // else
    ATTRIB, // =
    NOT, // !
    ARITHOP, 
    PLUS, // +
    MINUS, // -
    MULT, // *
    DIV, //  /
    RELOP,
    EQ, // ==
    NE, // !=
    GT, // >
    LT, // <
    NUMBER,
    INTEGER_LITERAL,
    TRUE, // true
    FALSE, // false
    LOGOP,
    AND, // &&
    RETURN, // return
    LENGTH, 
    EOF 
}
