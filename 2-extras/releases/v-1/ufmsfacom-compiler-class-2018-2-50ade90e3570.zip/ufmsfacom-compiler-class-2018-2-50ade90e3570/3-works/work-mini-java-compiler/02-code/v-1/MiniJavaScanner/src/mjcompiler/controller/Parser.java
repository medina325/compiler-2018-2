package mjcompiler.controller;

import mjcompiler.helpers.util.CompilerException;
import mjcompiler.helpers.util.EnumToken;
import mjcompiler.model.STEntry;
import mjcompiler.model.SymbolTable;
import mjcompiler.controller.Scanner;
import mjcompiler.model.Token;
import mjcompiler.view.main.MainScreenJF;

public class Parser 
{
    private Scanner scan;
    private SymbolTable globalST;
    private SymbolTable currentST;
    private Token lToken;
    
    public Parser(String inputFile) throws CompilerException
    {
        //Instancia a tabela de símbolos global e a inicializa
        globalST = new SymbolTable<STEntry>();
        initSymbolTable();
     
        //Faz o ponteiro para a tabela do escopo atual apontar para a tabela global
        currentST = globalST;
        
        //Instancia o analisador léxico
        scan = new Scanner(globalST, inputFile);
    }
    
    /*
     * Método que inicia o processo de análise sintática do compilador
     */
    public void execute() throws CompilerException
    {
        advance();
        program();
    }
    
    private void advance() throws CompilerException
    {
        lToken = scan.nextToken();
        
        System.out.print(lToken.name + "(" + lToken.lineNumber + ")" + " " );
    }
    
    private void match(EnumToken cTokenName) throws CompilerException
    {
        if (lToken.name == cTokenName)
            advance();
        else
        {            //Erro
            throw new CompilerException("Token inesperado: " + lToken.name);
        }
    }
    /*
     * Método para o símbolo inicial da gramática
     */    
    private void program() throws CompilerException
    {
        mainClass();
        
        while (lToken.name == EnumToken.CLASS) 
            classDeclaration();
        
        match(EnumToken.EOF);
        System.out.println("\nCompilação encerrada com sucesso");
        
    }    
    
    private void mainClass() throws CompilerException
    {
        match(EnumToken.CLASS);
        match(EnumToken.ID);
        match(EnumToken.LBRACE);
        match(EnumToken.PUBLIC);
        match(EnumToken.STATIC);
        match(EnumToken.VOID);
        match(EnumToken.MAIN);
        match(EnumToken.LPARENTHESE);
        match(EnumToken.STRING);
        match(EnumToken.LBRACKET);
        match(EnumToken.RBRACKET);
        match(EnumToken.ID);
        match(EnumToken.RPARENTHESE);
        match(EnumToken.LBRACE);
        statement();
        match(EnumToken.RBRACE);
        match(EnumToken.RBRACE);
        
    }
    private void classDeclaration() throws CompilerException
    {
        match(EnumToken.CLASS);
        match(EnumToken.ID);
        if(lToken.name == EnumToken.EXTENDS)
        {
            match(EnumToken.EXTENDS);
            match(EnumToken.ID);
        }
        match(EnumToken.LBRACE);
        while(lToken.name == EnumToken.INT || lToken.name == EnumToken.BOOLEAN || lToken.name == EnumToken.ID)
        {
            varDeclaration();
        }
        while(lToken.name == EnumToken.PUBLIC)
        {
            methodDeclaration();
        }
        match(EnumToken.RBRACE);
    }
    private void varDeclaration() throws CompilerException 
    {
        type();
        match(EnumToken.ID);
        match(EnumToken.SEMICOLON);
    }
    private void methodDeclaration() throws CompilerException {
        match(EnumToken.PUBLIC);
        type();
        match(EnumToken.ID);
        match(EnumToken.LPARENTHESE);
        if(lToken.name == EnumToken.INT || lToken.name == EnumToken.BOOLEAN || lToken.name == EnumToken.ID){
            type();
            match(EnumToken.ID);
            while(lToken.name == EnumToken.COMMA){
                match(EnumToken.COMMA);
                type();
                match(EnumToken.ID);
            }
        }
        match(EnumToken.RPARENTHESE);
        while(lToken.name == EnumToken.INT || lToken.name == EnumToken.BOOLEAN || lToken.name == EnumToken.ID)
        {
            varDeclaration();
        }
        while(lToken.name == EnumToken.LBRACKET || lToken.name == EnumToken.IF || lToken.name == EnumToken.WHILE ||
              lToken.name == EnumToken.SOPRINTLN ||lToken.name == EnumToken.ID)
        {
            statement();
        }
        match(EnumToken.RETURN);
        expression();
        match(EnumToken.SEMICOLON);
        match(EnumToken.RBRACE);
    }
    private void type() throws CompilerException{
        if(lToken.name == EnumToken.INT){
            match(EnumToken.INT);
            t_();
        }
        else if(lToken.name == EnumToken.BOOLEAN){
            match(EnumToken.BOOLEAN);
        }
        else{
            match(EnumToken.ID);
        }
    }
    private void t_() throws CompilerException{
        if(lToken.name == EnumToken.LBRACKET){
            match(EnumToken.LBRACKET);
            match(EnumToken.RBRACKET);
        }
        // Ou não faz nada
    }
    private void statement() throws CompilerException
    {
        if(lToken.name == EnumToken.LBRACE)
        {
            match(EnumToken.LBRACE);
            while(lToken.name == EnumToken.LBRACKET || lToken.name == EnumToken.IF || lToken.name == EnumToken.WHILE ||
                  lToken.name == EnumToken.SOPRINTLN ||lToken.name == EnumToken.ID)
            {
                statement();
            }
            match(EnumToken.RBRACE);
        }else if(lToken.name == EnumToken.IF){
            match(EnumToken.IF);
            match(EnumToken.LPARENTHESE);
            expression();
            match(EnumToken.RPARENTHESE);
            statement();
            match(EnumToken.ELSE);
            statement();
        } else if(lToken.name == EnumToken.WHILE){
            match(EnumToken.WHILE);
            match(EnumToken.LPARENTHESE);
            expression();
            match(EnumToken.RPARENTHESE);
            statement();
        } else if(lToken.name == EnumToken.SOPRINTLN){
            match(EnumToken.SOPRINTLN);
            match(EnumToken.LPARENTHESE);
            expression();
            match(EnumToken.RPARENTHESE);
            match(EnumToken.SEMICOLON);
        } else if(lToken.name == EnumToken.ID){
            match(EnumToken.ID);
            s_();
        }
        
    }
    private void s_() throws CompilerException{
        if(lToken.name == EnumToken.ATTRIB){
            match(EnumToken.ATTRIB);
            expression();
            match(EnumToken.SEMICOLON);
        }
        else{
            match(EnumToken.LBRACKET);
            expression();
            match(EnumToken.RBRACKET);
            match(EnumToken.ATTRIB);
            expression();
            match(EnumToken.SEMICOLON);
        }
    }
    private void expression() throws CompilerException{
        if(lToken.name == EnumToken.INTEGER_LITERAL){
            match(EnumToken.INTEGER_LITERAL);
            e_();
        } else if(lToken.name == EnumToken.TRUE){
            match(EnumToken.TRUE);
            e_();
        } else if(lToken.name == EnumToken.FALSE){
            match(EnumToken.FALSE);
            e_();
        } else if(lToken.name == EnumToken.ID){
            match(EnumToken.ID);
            e_();
        } else if(lToken.name == EnumToken.THIS){
            match(EnumToken.THIS);
            e_();
        } else if(lToken.name == EnumToken.NEW){
            match(EnumToken.NEW);
            e_Id();
        } else if(lToken.name == EnumToken.NOT){
            match(EnumToken.NOT);
            expression();
            e_();
        } else{ // (lToken.name == EnumToken.LPARENTHESE){
            match(EnumToken.LPARENTHESE);
            expression();
            match(EnumToken.RPARENTHESE);
            e_();
        }
    }
    private void e_Id() throws CompilerException{
        if(lToken.name == EnumToken.INT){
           match(EnumToken.INT);
           match(EnumToken.LBRACKET);
           expression();
           match(EnumToken.RBRACKET);
           e_();
        }else{//ID
           match(EnumToken.ID);
           match(EnumToken.LPARENTHESE);
           expression();
           match(EnumToken.RPARENTHESE);
           e_();
        }
    }
    private void e_() throws CompilerException{
        if(lToken.name == EnumToken.PLUS || lToken.name == EnumToken.MINUS || lToken.name == EnumToken.MULT || 
           lToken.name == EnumToken.DIV ||  lToken.name == EnumToken.EQ ||  lToken.name == EnumToken.NE || 
           lToken.name == EnumToken.GT || lToken.name == EnumToken.LT || lToken.name == EnumToken.AND ){
           op();
           expression();
           e_();
        }else if(lToken.name == EnumToken.LBRACKET){
           match(EnumToken.LBRACKET);
           expression();
           match(EnumToken.RBRACKET);
           e_();
        }else if(lToken.name == EnumToken.PERIOD){
           match(EnumToken.PERIOD);
           e_Period();
        }
        // Epsilon
    }
    private void e_Period() throws CompilerException{
        if(lToken.name == EnumToken.LENGTH){
            match(EnumToken.LENGTH);
            e_();
        }else{ // ID
            match(EnumToken.ID);
            if(lToken.name == EnumToken.INTEGER_LITERAL || lToken.name == EnumToken.TRUE || lToken.name == EnumToken.FALSE ||
               lToken.name == EnumToken.ID || lToken.name == EnumToken.THIS || lToken.name == EnumToken.NEW || 
               lToken.name == EnumToken.NOT || lToken.name == EnumToken.LPARENTHESE)
            {
                expression();
                while(lToken.name == EnumToken.COMMA){
                    match(EnumToken.COMMA);
                    expression();
                }
            }
            e_();
        }
    }
    private void op() throws CompilerException{
        if(lToken.name == EnumToken.PLUS){
            match(EnumToken.PLUS);
        }
        else if(lToken.name == EnumToken.MINUS){
            match(EnumToken.MINUS);
        }
        else if(lToken.name == EnumToken.MULT){
            match(EnumToken.MULT);
        }
        else if(lToken.name == EnumToken.DIV){
            match(EnumToken.DIV);
        }
        else if(lToken.name == EnumToken.EQ){
            match(EnumToken.EQ);
        }
        else if(lToken.name == EnumToken.NE){
            match(EnumToken.NE);
        }
        else if(lToken.name == EnumToken.GT){
            match(EnumToken.GT);
        }
        else if(lToken.name == EnumToken.LT){
            match(EnumToken.LT);
        }
        else{ //( lToken.name == EnumToken.AND ){
            match(EnumToken.AND);
        }
    }
    private void initSymbolTable()
    {
        // Lista de palavras reservadas
        globalST.add(new STEntry(EnumToken.BOOLEAN, "boolean", true));
        globalST.add(new STEntry(EnumToken.CLASS, "class", true));
        globalST.add(new STEntry(EnumToken.ELSE, "else", true));
        globalST.add(new STEntry(EnumToken.EXTENDS, "extends", true));
        globalST.add(new STEntry(EnumToken.FALSE, "false", true));
        globalST.add(new STEntry(EnumToken.IF, "if", true));
        globalST.add(new STEntry(EnumToken.INT, "int", true));
        globalST.add(new STEntry(EnumToken.LENGTH, "length", true));
        globalST.add(new STEntry(EnumToken.MAIN, "main", true));
        globalST.add(new STEntry(EnumToken.NEW, "new", true));
        globalST.add(new STEntry(EnumToken.PUBLIC, "public", true));
        globalST.add(new STEntry(EnumToken.RETURN, "return", true));
        globalST.add(new STEntry(EnumToken.STATIC, "static", true));
        globalST.add(new STEntry(EnumToken.STRING, "String", true));
        globalST.add(new STEntry(EnumToken.SOPRINTLN, "System.out.println", true));
        globalST.add(new STEntry(EnumToken.THIS, "this", true));
        globalST.add(new STEntry(EnumToken.TRUE, "true", true));
        globalST.add(new STEntry(EnumToken.VOID, "void", true));
        globalST.add(new STEntry(EnumToken.WHILE, "while", true));
    }

    public Scanner getScan() {
        return scan;
    }
    
    
}