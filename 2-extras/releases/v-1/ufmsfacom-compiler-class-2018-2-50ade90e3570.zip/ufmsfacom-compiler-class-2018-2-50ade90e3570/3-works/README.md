# Disciplina de Redes de Computadores.

## Trabalhos
**Nessa pasta contém os trabalhos da disciplina de Redes de Computadores, ufms 2018-2.**

## Dados dos trabalhos
#### Componentes
 * Mário de Araújo Carvalho
 * Jhonatan Froeder de Oliveira
#### Professor(a)
 * Ronaldo
#### Instituição
 * UFMS

# KANBAN MASTER DOS TRABALHOS
**Informações de todos os trabalhos já realizados!**
## A FAZER

## FAZENDO

## TESTANDO

## FEITO

# KANBAN's LITE DOS TRABALHOS
**Informações específicas de cada realizado!**

## A FAZER

## FAZENDO

## TESTANDO

## FEITO